"use client";

import { saveExpense } from "@/app/actions";
import type { Lookups } from "@/lib/data";
import { fmtDate, fmtINR, num, round, todayISO } from "@/lib/format";
import { CURRENCIES, type Currency, type Expense } from "@/lib/types";
import { useRef, useState, useTransition } from "react";
import { Button, Field, Input, Select, Textarea } from "./ui";

export type IncomeOption = { id: string; title: string; date: string | null; holder: string | null };

type Props = {
  lookups: Lookups;
  incomeOptions: IncomeOption[];
  initial?: Expense | null;
  preset?: { payee_id?: string; type_id?: string };
  onClose: () => void;
};

type F = {
  name: string;
  type_id: string;
  payee_id: string;
  amount_inr: string;
  payee_currency: Currency;
  payee_amount: string;
  conversion_rate: string;
  channel_id: string;
  transfer_fee_inr: string;
  status: "pending" | "paid";
  date: string;
  linked_income_id: string;
  notes: string;
};

type Num3 = "amount_inr" | "payee_amount" | "conversion_rate";
const NUM3: Num3[] = ["amount_inr", "payee_amount", "conversion_rate"];

const DEFAULTS_KEY = "expense-defaults-v1";
type Saved = {
  type_id?: string;
  payee_id?: string;
  channel_id?: string;
  currency?: Currency;
  rates?: Partial<Record<Currency, string>>;
};
const loadSaved = (): Saved => {
  try {
    return JSON.parse(localStorage.getItem(DEFAULTS_KEY) ?? "{}");
  } catch {
    return {};
  }
};

const s = (v: number | null | undefined) => (v === null || v === undefined ? "" : String(v));
const fixed = (n: number, dp: number) => (n > 0 && Number.isFinite(n) ? String(round(n, dp)) : "");

function initialState(initial: Expense | null | undefined, lk: Lookups, preset: Props["preset"]): F {
  if (initial) {
    return {
      name: initial.name,
      type_id: initial.type_id,
      payee_id: initial.payee_id ?? "",
      amount_inr: s(initial.amount_inr),
      payee_currency: initial.payee_currency,
      payee_amount: s(initial.payee_amount),
      conversion_rate: s(initial.conversion_rate),
      channel_id: initial.channel_id ?? "",
      transfer_fee_inr: s(initial.transfer_fee_inr),
      status: initial.status,
      date: initial.date,
      linked_income_id: initial.linked_income_id ?? "",
      notes: initial.notes ?? "",
    };
  }
  const saved = loadSaved();
  const has = (list: { id: string }[], id?: string) => (id && list.some((x) => x.id === id) ? id : "");
  const currency = saved.currency ?? "INR";
  return {
    name: "",
    type_id: has(lk.expenseTypes, preset?.type_id) || has(lk.expenseTypes, saved.type_id),
    payee_id: has(lk.people, preset?.payee_id) || has(lk.people, saved.payee_id),
    amount_inr: "",
    payee_currency: currency,
    payee_amount: "",
    conversion_rate: currency === "INR" ? "1" : saved.rates?.[currency] ?? "",
    channel_id: has(lk.channels, saved.channel_id),
    transfer_fee_inr: "",
    status: "paid",
    date: todayISO(),
    linked_income_id: "",
    notes: "",
  };
}

export function ExpenseForm({ lookups, incomeOptions, initial, preset, onClose }: Props) {
  const [f, setF] = useState<F>(() => initialState(initial, lookups, preset));
  // the two most recently typed of INR / payee amount / rate; the third is derived
  const order = useRef<Num3[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const nameRef = useRef<HTMLInputElement>(null);
  const isInr = f.payee_currency === "INR";

  const editNum = (field: Num3, value: string) =>
    setF((prev) => {
      const next: F = { ...prev, [field]: value };
      if (isInr) {
        // INR payee: amount paid and amount received are the same thing
        if (field === "amount_inr") next.payee_amount = value;
        if (field === "payee_amount") next.amount_inr = value;
        next.conversion_rate = "1";
        return next;
      }
      order.current = [field, ...order.current.filter((x) => x !== field)].slice(0, 2);
      const others = NUM3.filter((x) => x !== field);
      const target =
        order.current.length === 2
          ? NUM3.find((x) => !order.current.includes(x))!
          : others.find((x) => !num(next[x])) ?? null;
      if (!target) return next;

      const [a, b] = NUM3.filter((x) => x !== target);
      if (!num(next[a]) || !num(next[b])) return next;
      const inr = num(next.amount_inr);
      const amt = num(next.payee_amount);
      const rate = num(next.conversion_rate);
      if (target === "amount_inr") next.amount_inr = fixed(amt * rate, 2);
      else if (target === "payee_amount") next.payee_amount = fixed(inr / rate, 4);
      else next.conversion_rate = fixed(inr / amt, 6);
      return next;
    });

  const onCurrency = (currency: Currency) => {
    order.current = [];
    setF((prev) => {
      if (currency === "INR")
        return { ...prev, payee_currency: currency, conversion_rate: "1", payee_amount: prev.amount_inr };
      const rate = loadSaved().rates?.[currency] ?? "";
      return {
        ...prev,
        payee_currency: currency,
        conversion_rate: rate,
        payee_amount: "",
      };
    });
  };

  const payees = lookups.people.filter((p) => !p.archived || p.id === f.payee_id);

  const submit = (addAnother: boolean) => {
    setError(null);
    start(async () => {
      const res = await saveExpense({
        id: initial?.id,
        ...f,
        amount_inr: num(f.amount_inr),
        payee_amount: num(f.payee_amount),
        conversion_rate: num(f.conversion_rate) || 1,
        transfer_fee_inr: num(f.transfer_fee_inr),
      });
      if (!res.ok) return setError(res.error);

      const saved = loadSaved();
      localStorage.setItem(
        DEFAULTS_KEY,
        JSON.stringify({
          type_id: f.type_id,
          payee_id: f.payee_id,
          channel_id: f.channel_id,
          currency: f.payee_currency,
          rates: {
            ...saved.rates,
            ...(f.payee_currency !== "INR" && num(f.conversion_rate) ? { [f.payee_currency]: f.conversion_rate } : {}),
          },
        } satisfies Saved),
      );

      if (addAnother && !initial) {
        order.current = [];
        setF(initialState(null, lookups, preset));
        nameRef.current?.focus();
      } else onClose();
    });
  };

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        submit(false);
      }}
      className="flex flex-col gap-5"
    >
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="Name" className="sm:col-span-2">
          <Input
            ref={nameRef}
            value={f.name}
            onChange={(e) => setF({ ...f, name: e.target.value })}
            placeholder="e.g. November payout to Rahul"
            required
            autoFocus
          />
        </Field>
        <Field label="Type">
          <Select value={f.type_id} onChange={(e) => setF({ ...f, type_id: e.target.value })} required>
            <option value="">Select…</option>
            {lookups.expenseTypes
              .filter((x) => !x.archived || x.id === f.type_id)
              .map((x) => (
                <option key={x.id} value={x.id}>
                  {x.name}
                </option>
              ))}
          </Select>
        </Field>
        <Field label="Payee">
          <Select value={f.payee_id} onChange={(e) => setF({ ...f, payee_id: e.target.value })}>
            <option value="">None</option>
            {payees.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Paid via">
          <Select value={f.channel_id} onChange={(e) => setF({ ...f, channel_id: e.target.value })}>
            <option value="">Select…</option>
            {lookups.channels
              .filter((x) => !x.archived || x.id === f.channel_id)
              .map((x) => (
                <option key={x.id} value={x.id}>
                  {x.name}
                </option>
              ))}
          </Select>
        </Field>
        <Field label="Payee receives in">
          <Select value={f.payee_currency} onChange={(e) => onCurrency(e.target.value as Currency)}>
            {CURRENCIES.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </Select>
        </Field>
      </div>

      <fieldset className="rounded-lg border border-border p-4">
        <legend className="px-1 text-xs font-medium text-muted-fg">Amounts</legend>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
          <Field label="Amount paid (INR)">
            <Input type="number" step="any" min="0" inputMode="decimal" value={f.amount_inr} onChange={(e) => editNum("amount_inr", e.target.value)} />
          </Field>
          <Field label={`Payee received (${f.payee_currency})`}>
            <Input type="number" step="any" min="0" inputMode="decimal" value={f.payee_amount} onChange={(e) => editNum("payee_amount", e.target.value)} />
          </Field>
          <Field label="Rate (INR per 1)" hint={isInr ? undefined : "Fill any two, third is calculated"}>
            <Input type="number" step="any" min="0" inputMode="decimal" value={f.conversion_rate} disabled={isInr} onChange={(e) => editNum("conversion_rate", e.target.value)} />
          </Field>
          <Field label="Transfer fee (INR)">
            <Input type="number" step="any" min="0" inputMode="decimal" value={f.transfer_fee_inr} onChange={(e) => setF({ ...f, transfer_fee_inr: e.target.value })} />
          </Field>
        </div>
      </fieldset>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="Status">
          <Select value={f.status} onChange={(e) => setF({ ...f, status: e.target.value as F["status"] })}>
            <option value="paid">Paid</option>
            <option value="pending">Pending</option>
          </Select>
        </Field>
        <Field label={f.status === "paid" ? "Date paid" : "Due date"}>
          <Input type="date" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} required />
        </Field>
        <Field label="Linked income (optional)" className="sm:col-span-2" hint="The income this payout came from">
          <Select value={f.linked_income_id} onChange={(e) => setF({ ...f, linked_income_id: e.target.value })}>
            <option value="">None</option>
            {incomeOptions.map((i) => (
              <option key={i.id} value={i.id}>
                {i.title} {i.holder ? `(${i.holder})` : ""} {i.date ? `- ${fmtDate(i.date)}` : ""}
              </option>
            ))}
          </Select>
        </Field>
      </div>

      <Field label="Notes">
        <Textarea value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} />
      </Field>

      {num(f.amount_inr) > 0 && (
        <p className="text-xs text-muted-fg">
          Total out of pocket: {fmtINR(num(f.amount_inr) + num(f.transfer_fee_inr))}
        </p>
      )}
      {error && <p className="text-sm text-red-600">{error}</p>}

      <div className="sticky bottom-0 -mx-5 -mb-5 flex flex-wrap justify-end gap-2 border-t border-border bg-bg px-5 py-3">
        <Button type="button" variant="ghost" onClick={onClose}>
          Cancel
        </Button>
        {!initial && (
          <Button type="button" variant="outline" disabled={pending} onClick={() => submit(true)}>
            Save &amp; add another
          </Button>
        )}
        <Button type="submit" disabled={pending}>
          {pending ? "Saving…" : "Save"}
        </Button>
      </div>
    </form>
  );
}
