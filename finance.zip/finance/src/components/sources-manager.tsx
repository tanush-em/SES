"use client";

import { saveSource, setArchived } from "@/app/actions";
import { fmtINR } from "@/lib/format";
import { SOURCE_TYPE_LABEL, type Source, type SourceType } from "@/lib/types";
import { Archive, ArchiveRestore, Pencil, Plus } from "lucide-react";
import Link from "next/link";
import { useState, useTransition } from "react";
import { Badge, Button, EmptyState, Field, Input, PageHeader, Select, Sheet, Textarea } from "./ui";

export type SourceRow = Source & { total: number; count: number };

export function SourcesManager({ sources }: { sources: SourceRow[] }) {
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Source | null>(null);
  const [showArchived, setShowArchived] = useState(false);
  const [key, setKey] = useState(0);
  const [, start] = useTransition();

  const visible = sources.filter((s) => showArchived || !s.archived);
  const openForm = (s: Source | null) => {
    setEditing(s);
    setKey((k) => k + 1);
    setOpen(true);
  };

  return (
    <>
      <PageHeader
        title="Sources"
        description="Platforms, companies and direct clients that pay you."
        actions={
          <Button onClick={() => openForm(null)}>
            <Plus className="h-4 w-4" /> Add source
          </Button>
        }
      />
      <label className="mb-3 flex items-center gap-2 text-sm text-muted-fg">
        <input type="checkbox" checked={showArchived} onChange={(e) => setShowArchived(e.target.checked)} />
        Show archived
      </label>

      {visible.length === 0 ? (
        <EmptyState>No sources yet. Add Mercor, Upwork, AT&amp;T and so on.</EmptyState>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-border bg-card">
          <table className="w-full min-w-[560px] text-sm">
            <thead className="border-b border-border text-left text-xs text-muted-fg">
              <tr>
                <th className="px-3 py-2 font-medium">Name</th>
                <th className="px-3 py-2 font-medium">Type</th>
                <th className="px-3 py-2 text-right font-medium">Payouts</th>
                <th className="px-3 py-2 text-right font-medium">Received (INR)</th>
                <th className="px-3 py-2" />
              </tr>
            </thead>
            <tbody>
              {visible.map((s) => (
                <tr key={s.id} className="border-b border-border last:border-0 hover:bg-muted/50">
                  <td className="px-3 py-2">
                    <Link href={`/sources/${s.id}`} className="font-medium hover:underline">
                      {s.name}
                    </Link>
                    {s.archived && <span className="ml-2"><Badge>archived</Badge></span>}
                  </td>
                  <td className="px-3 py-2">{SOURCE_TYPE_LABEL[s.type]}</td>
                  <td className="px-3 py-2 text-right tabular-nums">{s.count}</td>
                  <td className="px-3 py-2 text-right font-medium tabular-nums">{fmtINR(s.total, true)}</td>
                  <td className="px-3 py-2">
                    <div className="flex justify-end gap-1">
                      <Button variant="ghost" size="icon" title="Edit" onClick={() => openForm(s)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        title={s.archived ? "Restore" : "Archive"}
                        onClick={() => start(async () => void (await setArchived("sources", s.id, !s.archived)))}
                      >
                        {s.archived ? <ArchiveRestore className="h-4 w-4" /> : <Archive className="h-4 w-4" />}
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Sheet open={open} onClose={() => setOpen(false)} title={editing ? "Edit source" : "Add source"}>
        <SourceForm key={key} initial={editing} onClose={() => setOpen(false)} />
      </Sheet>
    </>
  );
}

function SourceForm({ initial, onClose }: { initial: Source | null; onClose: () => void }) {
  const [name, setName] = useState(initial?.name ?? "");
  const [type, setType] = useState<SourceType>(initial?.type ?? "platform");
  const [notes, setNotes] = useState(initial?.notes ?? "");
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  return (
    <form
      className="flex flex-col gap-4"
      onSubmit={(e) => {
        e.preventDefault();
        setError(null);
        start(async () => {
          const res = await saveSource({ id: initial?.id, name, type, notes });
          if (!res.ok) return setError(res.error);
          onClose();
        });
      }}
    >
      <Field label="Name">
        <Input value={name} onChange={(e) => setName(e.target.value)} required autoFocus />
      </Field>
      <Field label="Type">
        <Select value={type} onChange={(e) => setType(e.target.value as SourceType)}>
          {(Object.keys(SOURCE_TYPE_LABEL) as SourceType[]).map((t) => (
            <option key={t} value={t}>
              {SOURCE_TYPE_LABEL[t]}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Notes">
        <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} />
      </Field>
      {error && <p className="text-sm text-red-600">{error}</p>}
      <div className="flex justify-end gap-2">
        <Button type="button" variant="ghost" onClick={onClose}>
          Cancel
        </Button>
        <Button type="submit" disabled={pending}>
          {pending ? "Saving…" : "Save"}
        </Button>
      </div>
    </form>
  );
}
