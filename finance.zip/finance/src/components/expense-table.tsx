"use client";

import { deleteExpense, markExpensePaid } from "@/app/actions";
import type { Lookups } from "@/lib/data";
import { fmtDate, fmtForeign, fmtINR, num, todayISO } from "@/lib/format";
import type { Expense, Income } from "@/lib/types";
import { Check, Pencil, Plus, Trash2 } from "lucide-react";
import { useMemo, useState, useTransition } from "react";
import { ExpenseForm, type IncomeOption } from "./expense-form";
import { Badge, Button, EmptyState, Input, PageHeader, Select, Sheet } from "./ui";

export function ExpenseTable({
  expenses,
  incomes,
  lookups,
  preset,
  title = "Expenses",
}: {
  expenses: Expense[];
  incomes: Income[];
  lookups: Lookups;
  preset?: { payee?: string };
  title?: string;
}) {
  const [editing, setEditing] = useState<Expense | null>(null);
  const [open, setOpen] = useState(false);
  const [formKey, setFormKey] = useState(0);
  const [, start] = useTransition();

  const [q, setQ] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [type, setType] = useState("");
  const [payee, setPayee] = useState(preset?.payee ?? "");
  const [status, setStatus] = useState("");
  const [currency, setCurrency] = useState("");
  const [channel, setChannel] = useState("");

  const incomeOptions: IncomeOption[] = useMemo(
    () =>
      incomes
        .map((i) => ({
          id: i.id,
          title: i.title,
          date: i.date_received ?? i.expected_date,
          holder: i.people?.name ?? null,
        }))
        .sort((a, b) => (b.date ?? "").localeCompare(a.date ?? ""))
        .slice(0, 300),
    [incomes],
  );

  const rows = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return expenses
      .filter(
        (e) =>
          (!needle || e.name.toLowerCase().includes(needle) || (e.notes ?? "").toLowerCase().includes(needle)) &&
          (!from || e.date >= from) &&
          (!to || e.date <= to) &&
          (!type || e.type_id === type) &&
          (!payee || e.payee_id === payee) &&
          (!status || e.status === status) &&
          (!currency || e.payee_currency === currency) &&
          (!channel || e.channel_id === channel),
      )
      .sort((a, b) => b.date.localeCompare(a.date) || b.created_at.localeCompare(a.created_at));
  }, [expenses, q, from, to, type, payee, status, currency, channel]);

  const totals = useMemo(() => {
    let paid = 0,
      pending = 0,
      fees = 0;
    for (const e of rows) {
      if (e.status === "paid") {
        paid += num(e.amount_inr);
        fees += num(e.transfer_fee_inr);
      } else pending += num(e.amount_inr);
    }
    return { paid, pending, fees };
  }, [rows]);

  const openForm = (e: Expense | null) => {
    setEditing(e);
    setFormKey((k) => k + 1);
    setOpen(true);
  };

  return (
    <>
      <PageHeader
        title={title}
        description="Payouts, subscriptions and personal draws."
        actions={
          <Button onClick={() => openForm(null)}>
            <Plus className="h-4 w-4" /> Add expense
          </Button>
        }
      />

      <div className="mb-4 grid grid-cols-2 gap-2 md:grid-cols-4 lg:grid-cols-5">
        <Input placeholder="Search name or notes" value={q} onChange={(e) => setQ(e.target.value)} className="col-span-2" />
        <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} aria-label="From date" />
        <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} aria-label="To date" />
        <Select value={type} onChange={(e) => setType(e.target.value)}>
          <option value="">All types</option>
          {lookups.expenseTypes.map((x) => (
            <option key={x.id} value={x.id}>{x.name}</option>
          ))}
        </Select>
        <Select value={payee} onChange={(e) => setPayee(e.target.value)}>
          <option value="">All payees</option>
          {lookups.people.map((x) => (
            <option key={x.id} value={x.id}>{x.name}</option>
          ))}
        </Select>
        <Select value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">Any status</option>
          <option value="paid">Paid</option>
          <option value="pending">Pending</option>
        </Select>
        <Select value={currency} onChange={(e) => setCurrency(e.target.value)}>
          <option value="">Any currency</option>
          <option>USD</option>
          <option>USDT</option>
          <option>INR</option>
        </Select>
        <Select value={channel} onChange={(e) => setChannel(e.target.value)}>
          <option value="">Any channel</option>
          {lookups.channels.map((x) => (
            <option key={x.id} value={x.id}>{x.name}</option>
          ))}
        </Select>
      </div>

      <div className="mb-3 flex flex-wrap gap-x-6 gap-y-1 text-sm">
        <span><span className="text-muted-fg">Entries:</span> {rows.length}</span>
        <span><span className="text-muted-fg">Paid:</span> <b>{fmtINR(totals.paid)}</b></span>
        <span><span className="text-muted-fg">Pending:</span> <b>{fmtINR(totals.pending)}</b></span>
        <span><span className="text-muted-fg">Transfer fees:</span> <b>{fmtINR(totals.fees)}</b></span>
      </div>

      {rows.length === 0 ? (
        <EmptyState>
          {expenses.length === 0 ? "No expenses yet." : "No entries match these filters."}
        </EmptyState>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-border bg-card">
          <table className="w-full min-w-[900px] text-sm">
            <thead className="border-b border-border text-left text-xs text-muted-fg">
              <tr>
                <th className="px-3 py-2 font-medium">Date</th>
                <th className="px-3 py-2 font-medium">Name</th>
                <th className="px-3 py-2 font-medium">Type</th>
                <th className="px-3 py-2 font-medium">Payee</th>
                <th className="px-3 py-2 font-medium">Via</th>
                <th className="px-3 py-2 text-right font-medium">Payee got</th>
                <th className="px-3 py-2 text-right font-medium">Rate</th>
                <th className="px-3 py-2 text-right font-medium">INR</th>
                <th className="px-3 py-2 font-medium">Status</th>
                <th className="px-3 py-2" />
              </tr>
            </thead>
            <tbody>
              {rows.map((e) => (
                <tr key={e.id} className="border-b border-border last:border-0 hover:bg-muted/50">
                  <td className="px-3 py-2 whitespace-nowrap">{fmtDate(e.date)}</td>
                  <td className="px-3 py-2">
                    <div className="font-medium">{e.name}</div>
                    {e.incomes?.title && <div className="text-xs text-muted-fg">from {e.incomes.title}</div>}
                  </td>
                  <td className="px-3 py-2">{e.expense_types?.name}</td>
                  <td className="px-3 py-2">{e.people?.name ?? "-"}</td>
                  <td className="px-3 py-2">{e.payment_channels?.name ?? "-"}</td>
                  <td className="px-3 py-2 text-right whitespace-nowrap tabular-nums">
                    {e.payee_currency === "INR" ? "-" : fmtForeign(e.payee_amount, e.payee_currency)}
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums">
                    {e.payee_currency === "INR" ? "-" : e.conversion_rate}
                  </td>
                  <td className="px-3 py-2 text-right font-medium whitespace-nowrap tabular-nums">
                    {fmtINR(e.amount_inr)}
                  </td>
                  <td className="px-3 py-2">
                    <Badge tone={e.status === "paid" ? "good" : "warn"}>{e.status}</Badge>
                  </td>
                  <td className="px-3 py-2">
                    <div className="flex justify-end gap-1">
                      {e.status === "pending" && (
                        <Button
                          variant="ghost"
                          size="icon"
                          title="Mark paid today"
                          onClick={() => start(async () => void (await markExpensePaid(e.id, todayISO())))}
                        >
                          <Check className="h-4 w-4" />
                        </Button>
                      )}
                      <Button variant="ghost" size="icon" title="Edit" onClick={() => openForm(e)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        title="Delete"
                        onClick={() => {
                          if (confirm(`Delete "${e.name}"?`)) start(async () => void (await deleteExpense(e.id)));
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Sheet open={open} onClose={() => setOpen(false)} title={editing ? "Edit expense" : "Add expense"}>
        <ExpenseForm
          key={formKey}
          lookups={lookups}
          incomeOptions={incomeOptions}
          initial={editing}
          preset={preset?.payee ? { payee_id: preset.payee } : undefined}
          onClose={() => setOpen(false)}
        />
      </Sheet>
    </>
  );
}
