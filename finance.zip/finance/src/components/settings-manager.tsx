"use client";

import { deleteTag, saveChannel, saveExpenseType, saveTag, setArchived } from "@/app/actions";
import type { Lookups } from "@/lib/data";
import { Archive, ArchiveRestore, X } from "lucide-react";
import { useState, useTransition } from "react";
import { Badge, Button, Card, Input, PageHeader } from "./ui";

function AddRow({
  placeholder,
  onAdd,
  children,
}: {
  placeholder: string;
  onAdd: (name: string) => Promise<{ ok: boolean; error?: string }>;
  children?: React.ReactNode;
}) {
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  return (
    <form
      className="mt-3"
      onSubmit={(e) => {
        e.preventDefault();
        setError(null);
        start(async () => {
          const res = await onAdd(name);
          if (!res.ok) return setError(res.error ?? "Failed");
          setName("");
        });
      }}
    >
      <div className="flex flex-wrap items-center gap-2">
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder={placeholder} className="max-w-56" />
        {children}
        <Button type="submit" variant="outline" disabled={pending || !name.trim()}>
          Add
        </Button>
      </div>
      {error && <p className="mt-1 text-sm text-red-600">{error}</p>}
    </form>
  );
}

export function SettingsManager({ lookups }: { lookups: Lookups }) {
  const [, start] = useTransition();
  const [payoutKind, setPayoutKind] = useState(false);

  const archive = (table: "payment_channels" | "expense_types", id: string, archived: boolean) =>
    start(async () => void (await setArchived(table, id, archived)));

  return (
    <>
      <PageHeader title="Settings" description="Lists used in the income and expense forms." />
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <h2 className="text-sm font-semibold">Payment channels</h2>
          <ul className="mt-3 divide-y divide-border">
            {lookups.channels.map((c) => (
              <li key={c.id} className="flex items-center justify-between py-2 text-sm">
                <span className={c.archived ? "text-muted-fg line-through" : ""}>{c.name}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  title={c.archived ? "Restore" : "Archive"}
                  onClick={() => archive("payment_channels", c.id, !c.archived)}
                >
                  {c.archived ? <ArchiveRestore className="h-4 w-4" /> : <Archive className="h-4 w-4" />}
                </Button>
              </li>
            ))}
          </ul>
          <AddRow placeholder="e.g. Wise" onAdd={(name) => saveChannel({ name })} />
        </Card>

        <Card>
          <h2 className="text-sm font-semibold">Expense types</h2>
          <ul className="mt-3 divide-y divide-border">
            {lookups.expenseTypes.map((t) => (
              <li key={t.id} className="flex items-center justify-between py-2 text-sm">
                <span className={t.archived ? "text-muted-fg line-through" : ""}>
                  {t.name}
                  {t.kind === "account_holder_payout" && (
                    <span className="ml-2">
                      <Badge tone="good">counts toward owed</Badge>
                    </span>
                  )}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  title={t.archived ? "Restore" : "Archive"}
                  onClick={() => archive("expense_types", t.id, !t.archived)}
                >
                  {t.archived ? <ArchiveRestore className="h-4 w-4" /> : <Archive className="h-4 w-4" />}
                </Button>
              </li>
            ))}
          </ul>
          <AddRow
            placeholder="e.g. Equipment"
            onAdd={(name) => saveExpenseType({ name, kind: payoutKind ? "account_holder_payout" : "other" })}
          >
            <label className="flex items-center gap-1.5 text-xs text-muted-fg">
              <input type="checkbox" checked={payoutKind} onChange={(e) => setPayoutKind(e.target.checked)} />
              Account-holder payout
            </label>
          </AddRow>
        </Card>

        <Card className="lg:col-span-2">
          <h2 className="text-sm font-semibold">Tags</h2>
          <div className="mt-3 flex flex-wrap gap-2">
            {lookups.tags.length === 0 && <p className="text-sm text-muted-fg">No tags yet.</p>}
            {lookups.tags.map((t) => (
              <span key={t.id} className="inline-flex items-center gap-1 rounded-full bg-muted py-1 pr-1 pl-3 text-xs">
                {t.name}
                <button
                  className="rounded-full p-0.5 hover:bg-border"
                  aria-label={`Delete ${t.name}`}
                  onClick={() => {
                    if (confirm(`Delete tag "${t.name}"? It is removed from all income entries.`))
                      start(async () => void (await deleteTag(t.id)));
                  }}
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
          </div>
          <AddRow placeholder="New tag" onAdd={(name) => saveTag({ name })} />
        </Card>
      </div>
    </>
  );
}
