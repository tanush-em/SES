"use client";

import { fyStartYear } from "@/lib/format";
import { usePathname, useRouter } from "next/navigation";
import { Input, Select } from "./ui";

type Mode = "month" | "fy" | "all" | "custom";

export function RangePicker({
  mode,
  month,
  fy,
  from,
  to,
}: {
  mode: Mode;
  month: string;
  fy: number;
  from: string;
  to: string;
}) {
  const router = useRouter();
  const pathname = usePathname();

  const go = (params: Record<string, string>) => {
    const q = new URLSearchParams(params);
    router.push(`${pathname}?${q.toString()}`);
  };

  const thisFy = fyStartYear();
  const years = Array.from({ length: 6 }, (_, k) => thisFy - k);

  return (
    <div className="flex flex-wrap items-center gap-2">
      <Select
        className="w-36"
        value={mode}
        onChange={(e) => {
          const m = e.target.value as Mode;
          if (m === "month") go({ range: m, month });
          else if (m === "fy") go({ range: m, fy: String(fy) });
          else if (m === "custom") go({ range: m, from, to });
          else go({ range: m });
        }}
      >
        <option value="month">Month</option>
        <option value="fy">Financial year</option>
        <option value="custom">Custom</option>
        <option value="all">All time</option>
      </Select>
      {mode === "month" && (
        <Input
          type="month"
          className="w-44"
          value={month}
          onChange={(e) => e.target.value && go({ range: "month", month: e.target.value })}
        />
      )}
      {mode === "fy" && (
        <Select className="w-36" value={fy} onChange={(e) => go({ range: "fy", fy: e.target.value })}>
          {years.map((y) => (
            <option key={y} value={y}>
              FY {y}-{String(y + 1).slice(2)}
            </option>
          ))}
        </Select>
      )}
      {mode === "custom" && (
        <>
          <Input type="date" className="w-40" value={from} onChange={(e) => go({ range: "custom", from: e.target.value, to })} />
          <Input type="date" className="w-40" value={to} onChange={(e) => go({ range: "custom", from, to: e.target.value })} />
        </>
      )}
    </div>
  );
}
