"use client";

import { savePerson, setArchived } from "@/app/actions";
import { fmtINR } from "@/lib/format";
import type { Person } from "@/lib/types";
import { Archive, ArchiveRestore, Pencil, Plus } from "lucide-react";
import Link from "next/link";
import { useState, useTransition } from "react";
import { Badge, Button, EmptyState, Field, Input, PageHeader, Sheet, Textarea } from "./ui";

export type PersonRow = Person & { earned: number; paidOut: number };

export function PeopleManager({ people }: { people: PersonRow[] }) {
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Person | null>(null);
  const [showArchived, setShowArchived] = useState(false);
  const [key, setKey] = useState(0);
  const [, start] = useTransition();

  const visible = people.filter((p) => showArchived || !p.archived);
  const openForm = (p: Person | null) => {
    setEditing(p);
    setKey((k) => k + 1);
    setOpen(true);
  };

  return (
    <>
      <PageHeader
        title="People"
        description="Account holders, employees and anyone you pay."
        actions={
          <Button onClick={() => openForm(null)}>
            <Plus className="h-4 w-4" /> Add person
          </Button>
        }
      />
      <label className="mb-3 flex items-center gap-2 text-sm text-muted-fg">
        <input type="checkbox" checked={showArchived} onChange={(e) => setShowArchived(e.target.checked)} />
        Show archived
      </label>

      {visible.length === 0 ? (
        <EmptyState>No people yet.</EmptyState>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-border bg-card">
          <table className="w-full min-w-[640px] text-sm">
            <thead className="border-b border-border text-left text-xs text-muted-fg">
              <tr>
                <th className="px-3 py-2 font-medium">Name</th>
                <th className="px-3 py-2 font-medium">Roles</th>
                <th className="px-3 py-2 text-right font-medium">Earned on account</th>
                <th className="px-3 py-2 text-right font-medium">Paid out</th>
                <th className="px-3 py-2 text-right font-medium">Balance</th>
                <th className="px-3 py-2" />
              </tr>
            </thead>
            <tbody>
              {visible.map((p) => (
                <tr key={p.id} className="border-b border-border last:border-0 hover:bg-muted/50">
                  <td className="px-3 py-2">
                    <Link href={`/people/${p.id}`} className="font-medium hover:underline">
                      {p.name}
                    </Link>
                    {p.archived && <span className="ml-2"><Badge>archived</Badge></span>}
                  </td>
                  <td className="px-3 py-2">
                    <div className="flex flex-wrap gap-1">
                      {p.is_self && <Badge tone="good">Self</Badge>}
                      {p.is_account_holder && !p.is_self && <Badge>Account holder</Badge>}
                      {p.is_payee && <Badge>Payee</Badge>}
                    </div>
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums">{p.earned ? fmtINR(p.earned, true) : "-"}</td>
                  <td className="px-3 py-2 text-right tabular-nums">{p.paidOut ? fmtINR(p.paidOut, true) : "-"}</td>
                  <td className="px-3 py-2 text-right font-medium tabular-nums">
                    {p.is_self ? "-" : p.earned || p.paidOut ? fmtINR(p.earned - p.paidOut, true) : "-"}
                  </td>
                  <td className="px-3 py-2">
                    <div className="flex justify-end gap-1">
                      <Button variant="ghost" size="icon" title="Edit" onClick={() => openForm(p)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      {!p.is_self && (
                        <Button
                          variant="ghost"
                          size="icon"
                          title={p.archived ? "Restore" : "Archive"}
                          onClick={() => start(async () => void (await setArchived("people", p.id, !p.archived)))}
                        >
                          {p.archived ? <ArchiveRestore className="h-4 w-4" /> : <Archive className="h-4 w-4" />}
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Sheet open={open} onClose={() => setOpen(false)} title={editing ? "Edit person" : "Add person"}>
        <PersonForm key={key} initial={editing} onClose={() => setOpen(false)} />
      </Sheet>
    </>
  );
}

function PersonForm({ initial, onClose }: { initial: Person | null; onClose: () => void }) {
  const [name, setName] = useState(initial?.name ?? "");
  const [holder, setHolder] = useState(initial?.is_account_holder ?? false);
  const [payee, setPayee] = useState(initial?.is_payee ?? true);
  const [contact, setContact] = useState(initial?.contact ?? "");
  const [notes, setNotes] = useState(initial?.notes ?? "");
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  return (
    <form
      className="flex flex-col gap-4"
      onSubmit={(e) => {
        e.preventDefault();
        setError(null);
        start(async () => {
          const res = await savePerson({
            id: initial?.id,
            name,
            is_account_holder: holder,
            is_payee: payee,
            contact,
            notes,
          });
          if (!res.ok) return setError(res.error);
          onClose();
        });
      }}
    >
      <Field label="Name">
        <Input value={name} onChange={(e) => setName(e.target.value)} required autoFocus />
      </Field>
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={holder} onChange={(e) => setHolder(e.target.checked)} />
        Account holder (platform accounts run on their behalf)
      </label>
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={payee} onChange={(e) => setPayee(e.target.checked)} />
        Payee (you pay them)
      </label>
      <Field label="Contact">
        <Input value={contact} onChange={(e) => setContact(e.target.value)} placeholder="Phone, email, UPI…" />
      </Field>
      <Field label="Notes">
        <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} />
      </Field>
      {error && <p className="text-sm text-red-600">{error}</p>}
      <div className="flex justify-end gap-2">
        <Button type="button" variant="ghost" onClick={onClose}>
          Cancel
        </Button>
        <Button type="submit" disabled={pending}>
          {pending ? "Saving…" : "Save"}
        </Button>
      </div>
    </form>
  );
}
