"use client";

import { deleteIncome, markIncomeReceived } from "@/app/actions";
import type { Lookups } from "@/lib/data";
import { fmtDate, fmtForeign, fmtINR, incomeMetrics, num, todayISO } from "@/lib/format";
import type { Income } from "@/lib/types";
import { Check, Pencil, Plus, Trash2 } from "lucide-react";
import { useMemo, useState, useTransition } from "react";
import { IncomeForm } from "./income-form";
import { Badge, Button, EmptyState, Input, PageHeader, Select, Sheet } from "./ui";

const when = (i: Income) =>
  i.status === "received" ? i.date_received ?? "" : i.expected_date ?? i.date_received ?? "";

export function IncomeTable({
  incomes,
  lookups,
  preset,
  title = "Income",
}: {
  incomes: Income[];
  lookups: Lookups;
  preset?: { source?: string; holder?: string };
  title?: string;
}) {
  const [editing, setEditing] = useState<Income | null>(null);
  const [open, setOpen] = useState(false);
  const [formKey, setFormKey] = useState(0);
  const [, start] = useTransition();

  const [q, setQ] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [source, setSource] = useState(preset?.source ?? "");
  const [holder, setHolder] = useState(preset?.holder ?? "");
  const [status, setStatus] = useState("");
  const [currency, setCurrency] = useState("");
  const [channel, setChannel] = useState("");
  const [tag, setTag] = useState("");

  const rows = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return incomes
      .filter((i) => {
        const d = when(i);
        return (
          (!needle || i.title.toLowerCase().includes(needle) || (i.notes ?? "").toLowerCase().includes(needle)) &&
          (!from || d >= from) &&
          (!to || d <= to) &&
          (!source || i.source_id === source) &&
          (!holder || i.account_holder_id === holder) &&
          (!status || i.status === status) &&
          (!currency || i.currency === currency) &&
          (!channel || i.channel_id === channel) &&
          (!tag || i.income_tags?.some((t) => t.tag_id === tag))
        );
      })
      .sort((a, b) => when(b).localeCompare(when(a)) || b.created_at.localeCompare(a.created_at));
  }, [incomes, q, from, to, source, holder, status, currency, channel, tag]);

  const totals = useMemo(() => {
    let received = 0,
      pending = 0,
      loss = 0;
    for (const i of rows) {
      const m = incomeMetrics(i);
      if (i.status === "received") {
        received += num(i.inr_received);
        loss += m.totalCost;
      } else pending += m.expectedInr || num(i.inr_received);
    }
    return { received, pending, loss };
  }, [rows]);

  const openNew = () => {
    setEditing(null);
    setFormKey((k) => k + 1);
    setOpen(true);
  };
  const openEdit = (i: Income) => {
    setEditing(i);
    setFormKey((k) => k + 1);
    setOpen(true);
  };
  const tagName = (id: string) => lookups.tags.find((t) => t.id === id)?.name ?? "";

  return (
    <>
      <PageHeader
        title={title}
        description="Every payout you receive, with fees and conversion."
        actions={
          <Button onClick={openNew}>
            <Plus className="h-4 w-4" /> Add income
          </Button>
        }
      />

      <div className="mb-4 grid grid-cols-2 gap-2 md:grid-cols-4 lg:grid-cols-5">
        <Input placeholder="Search name or notes" value={q} onChange={(e) => setQ(e.target.value)} className="col-span-2" />
        <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} aria-label="From date" />
        <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} aria-label="To date" />
        <Select value={source} onChange={(e) => setSource(e.target.value)}>
          <option value="">All sources</option>
          {lookups.sources.map((x) => (
            <option key={x.id} value={x.id}>{x.name}</option>
          ))}
        </Select>
        <Select value={holder} onChange={(e) => setHolder(e.target.value)}>
          <option value="">All account holders</option>
          {lookups.people.map((x) => (
            <option key={x.id} value={x.id}>{x.name}</option>
          ))}
        </Select>
        <Select value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">Any status</option>
          <option value="received">Received</option>
          <option value="pending">Pending</option>
        </Select>
        <Select value={currency} onChange={(e) => setCurrency(e.target.value)}>
          <option value="">Any currency</option>
          <option>USD</option>
          <option>USDT</option>
          <option>INR</option>
        </Select>
        <Select value={channel} onChange={(e) => setChannel(e.target.value)}>
          <option value="">Any channel</option>
          {lookups.channels.map((x) => (
            <option key={x.id} value={x.id}>{x.name}</option>
          ))}
        </Select>
        <Select value={tag} onChange={(e) => setTag(e.target.value)}>
          <option value="">Any tag</option>
          {lookups.tags.map((x) => (
            <option key={x.id} value={x.id}>{x.name}</option>
          ))}
        </Select>
      </div>

      <div className="mb-3 flex flex-wrap gap-x-6 gap-y-1 text-sm">
        <span><span className="text-muted-fg">Entries:</span> {rows.length}</span>
        <span><span className="text-muted-fg">Received:</span> <b>{fmtINR(totals.received)}</b></span>
        <span><span className="text-muted-fg">Pending:</span> <b>{fmtINR(totals.pending)}</b></span>
        <span><span className="text-muted-fg">Fees + FX loss:</span> <b>{fmtINR(totals.loss)}</b></span>
      </div>

      {rows.length === 0 ? (
        <EmptyState>
          {incomes.length === 0 ? "No income yet. Add your first payout." : "No entries match these filters."}
        </EmptyState>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-border bg-card">
          <table className="w-full min-w-[900px] text-sm">
            <thead className="border-b border-border text-left text-xs text-muted-fg">
              <tr>
                <th className="px-3 py-2 font-medium">Date</th>
                <th className="px-3 py-2 font-medium">Name</th>
                <th className="px-3 py-2 font-medium">Source</th>
                <th className="px-3 py-2 font-medium">Holder</th>
                <th className="px-3 py-2 font-medium">Via</th>
                <th className="px-3 py-2 text-right font-medium">Original</th>
                <th className="px-3 py-2 text-right font-medium">Rate</th>
                <th className="px-3 py-2 text-right font-medium">INR</th>
                <th className="px-3 py-2 text-right font-medium">Cost</th>
                <th className="px-3 py-2 font-medium">Status</th>
                <th className="px-3 py-2" />
              </tr>
            </thead>
            <tbody>
              {rows.map((i) => {
                const m = incomeMetrics(i);
                return (
                  <tr key={i.id} className="border-b border-border last:border-0 hover:bg-muted/50">
                    <td className="px-3 py-2 whitespace-nowrap">{fmtDate(when(i))}</td>
                    <td className="px-3 py-2">
                      <div className="font-medium">{i.title}</div>
                      {!!i.income_tags?.length && (
                        <div className="mt-0.5 flex flex-wrap gap-1">
                          {i.income_tags.map((t) => (
                            <Badge key={t.tag_id}>{tagName(t.tag_id)}</Badge>
                          ))}
                        </div>
                      )}
                    </td>
                    <td className="px-3 py-2">{i.sources?.name}</td>
                    <td className="px-3 py-2">{i.people?.name ?? "-"}</td>
                    <td className="px-3 py-2">{i.payment_channels?.name ?? "-"}</td>
                    <td className="px-3 py-2 text-right whitespace-nowrap tabular-nums">
                      {fmtForeign(i.gross_amount, i.currency)}
                    </td>
                    <td className="px-3 py-2 text-right tabular-nums">
                      {i.currency === "INR" ? "-" : i.conversion_rate}
                    </td>
                    <td className="px-3 py-2 text-right font-medium whitespace-nowrap tabular-nums">
                      {fmtINR(i.inr_received)}
                    </td>
                    <td className="px-3 py-2 text-right whitespace-nowrap tabular-nums text-muted-fg">
                      {i.currency === "INR" ? "-" : fmtINR(m.totalCost)}
                    </td>
                    <td className="px-3 py-2">
                      <Badge tone={i.status === "received" ? "good" : "warn"}>{i.status}</Badge>
                    </td>
                    <td className="px-3 py-2">
                      <div className="flex justify-end gap-1">
                        {i.status === "pending" && (
                          <Button
                            variant="ghost"
                            size="icon"
                            title="Mark received today"
                            onClick={() => start(async () => void (await markIncomeReceived(i.id, todayISO())))}
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                        )}
                        <Button variant="ghost" size="icon" title="Edit" onClick={() => openEdit(i)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          title="Delete"
                          onClick={() => {
                            if (confirm(`Delete "${i.title}"?`)) start(async () => void (await deleteIncome(i.id)));
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <Sheet open={open} onClose={() => setOpen(false)} title={editing ? "Edit income" : "Add income"}>
        <IncomeForm key={formKey} lookups={lookups} initial={editing} onClose={() => setOpen(false)} />
      </Sheet>
    </>
  );
}
