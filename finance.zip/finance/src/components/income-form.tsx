"use client";

import { saveIncome, saveTag } from "@/app/actions";
import type { Lookups } from "@/lib/data";
import { cn } from "@/lib/cn";
import { fmtForeign, fmtINR, incomeMetrics, num, round, todayISO } from "@/lib/format";
import { CURRENCIES, type Currency, type Income } from "@/lib/types";
import { useRef, useState, useTransition } from "react";
import { Button, Field, Input, Select, Textarea } from "./ui";

type Props = {
  lookups: Lookups;
  initial?: Income | null;
  onClose: () => void;
};

type F = {
  title: string;
  source_id: string;
  account_holder_id: string;
  channel_id: string;
  currency: Currency;
  gross_amount: string;
  platform_fee: string;
  transfer_fee: string;
  other_fee: string;
  net_foreign_amount: string;
  conversion_rate: string;
  inr_received: string;
  status: "pending" | "received";
  date_received: string;
  expected_date: string;
  period_start: string;
  period_end: string;
  notes: string;
  tag_ids: string[];
};

const DEFAULTS_KEY = "income-defaults-v1";
type Saved = {
  source_id?: string;
  account_holder_id?: string;
  channel_id?: string;
  currency?: Currency;
  rates?: Partial<Record<Currency, string>>;
};

const loadSaved = (): Saved => {
  try {
    return JSON.parse(localStorage.getItem(DEFAULTS_KEY) ?? "{}");
  } catch {
    return {};
  }
};

const s = (v: number | null | undefined) => (v === null || v === undefined ? "" : String(v));

function initialState(initial: Income | null | undefined, lk: Lookups): F {
  if (initial) {
    return {
      title: initial.title,
      source_id: initial.source_id,
      account_holder_id: initial.account_holder_id ?? "",
      channel_id: initial.channel_id ?? "",
      currency: initial.currency,
      gross_amount: s(initial.gross_amount),
      platform_fee: s(initial.platform_fee),
      transfer_fee: s(initial.transfer_fee),
      other_fee: s(initial.other_fee),
      net_foreign_amount: s(initial.net_foreign_amount),
      conversion_rate: s(initial.conversion_rate),
      inr_received: s(initial.inr_received),
      status: initial.status,
      date_received: initial.date_received ?? "",
      expected_date: initial.expected_date ?? "",
      period_start: initial.period_start ?? "",
      period_end: initial.period_end ?? "",
      notes: initial.notes ?? "",
      tag_ids: initial.income_tags?.map((t) => t.tag_id) ?? [],
    };
  }
  const saved = loadSaved();
  const currency = saved.currency ?? "USD";
  const selfId = lk.people.find((p) => p.is_self)?.id ?? "";
  const has = (list: { id: string }[], id?: string) => (id && list.some((x) => x.id === id) ? id : "");
  return {
    title: "",
    source_id: has(lk.sources, saved.source_id),
    account_holder_id: has(lk.people, saved.account_holder_id) || selfId,
    channel_id: has(lk.channels, saved.channel_id),
    currency,
    gross_amount: "",
    platform_fee: "",
    transfer_fee: "",
    other_fee: "",
    net_foreign_amount: "",
    conversion_rate: currency === "INR" ? "1" : saved.rates?.[currency] ?? "",
    inr_received: "",
    status: "received",
    date_received: todayISO(),
    expected_date: "",
    period_start: "",
    period_end: "",
    notes: "",
    tag_ids: [],
  };
}

const fixed = (n: number, dp: number) => (n ? String(round(n, dp)) : "");

export function IncomeForm({ lookups, initial, onClose }: Props) {
  const [f, setF] = useState<F>(() => initialState(initial, lookups));
  // once the user types into net/INR themselves, stop auto-filling them
  const touched = useRef({ net: !!initial, inr: !!initial });
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const [newTag, setNewTag] = useState("");
  const titleRef = useRef<HTMLInputElement>(null);

  const update = (patch: Partial<F>) =>
    setF((prev) => {
      const next = { ...prev, ...patch };
      const keys = Object.keys(patch);
      const feeKeys = ["gross_amount", "platform_fee", "transfer_fee", "other_fee"];

      if (!touched.current.net && keys.some((k) => feeKeys.includes(k))) {
        const net = Math.max(
          0,
          num(next.gross_amount) - num(next.platform_fee) - num(next.transfer_fee) - num(next.other_fee),
        );
        next.net_foreign_amount = fixed(net, 4);
      }
      if (
        !touched.current.inr &&
        keys.some((k) => [...feeKeys, "net_foreign_amount", "conversion_rate", "currency"].includes(k))
      ) {
        next.inr_received = fixed(num(next.net_foreign_amount) * (num(next.conversion_rate) || 0), 2);
      }
      return next;
    });

  const onCurrency = (currency: Currency) => {
    const rate =
      currency === "INR" ? "1" : loadSaved().rates?.[currency] ?? (f.currency === "INR" ? "" : f.conversion_rate);
    update({ currency, conversion_rate: rate });
  };

  const holders = lookups.people.filter(
    (p) => !p.archived && (p.is_self || p.is_account_holder || p.id === f.account_holder_id),
  );
  const m = incomeMetrics({
    currency: f.currency,
    gross_amount: num(f.gross_amount),
    platform_fee: num(f.platform_fee),
    transfer_fee: num(f.transfer_fee),
    other_fee: num(f.other_fee),
    net_foreign_amount: num(f.net_foreign_amount),
    conversion_rate: num(f.conversion_rate),
    inr_received: num(f.inr_received),
  });

  const submit = (addAnother: boolean) => {
    setError(null);
    start(async () => {
      const res = await saveIncome({
        id: initial?.id,
        ...f,
        gross_amount: num(f.gross_amount),
        platform_fee: num(f.platform_fee),
        transfer_fee: num(f.transfer_fee),
        other_fee: num(f.other_fee),
        net_foreign_amount: num(f.net_foreign_amount),
        conversion_rate: num(f.conversion_rate) || 1,
        inr_received: num(f.inr_received),
        date_received: f.status === "received" ? f.date_received : "",
        expected_date: f.status === "pending" ? f.expected_date : "",
      });
      if (!res.ok) return setError(res.error);

      const saved = loadSaved();
      localStorage.setItem(
        DEFAULTS_KEY,
        JSON.stringify({
          source_id: f.source_id,
          account_holder_id: f.account_holder_id,
          channel_id: f.channel_id,
          currency: f.currency,
          rates: { ...saved.rates, ...(f.currency !== "INR" && num(f.conversion_rate) ? { [f.currency]: f.conversion_rate } : {}) },
        } satisfies Saved),
      );

      if (addAnother && !initial) {
        touched.current = { net: false, inr: false };
        setF(initialState(null, lookups));
        titleRef.current?.focus();
      } else onClose();
    });
  };

  const addTag = () => {
    const name = newTag.trim();
    if (!name) return;
    start(async () => {
      const res = await saveTag({ name });
      if (!res.ok) return setError(res.error);
      setNewTag("");
      if (res.id) update({ tag_ids: [...f.tag_ids, res.id] });
    });
  };

  const isForeign = f.currency !== "INR";

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        submit(false);
      }}
      className="flex flex-col gap-5"
    >
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="Payment name" className="sm:col-span-2">
          <Input
            ref={titleRef}
            value={f.title}
            onChange={(e) => update({ title: e.target.value })}
            placeholder="e.g. Mercor weekly payout"
            required
            autoFocus
          />
        </Field>
        <Field label="Source">
          <Select value={f.source_id} onChange={(e) => update({ source_id: e.target.value })} required>
            <option value="">Select…</option>
            {lookups.sources
              .filter((x) => !x.archived || x.id === f.source_id)
              .map((x) => (
                <option key={x.id} value={x.id}>
                  {x.name}
                </option>
              ))}
          </Select>
        </Field>
        <Field label="Account holder">
          <Select value={f.account_holder_id} onChange={(e) => update({ account_holder_id: e.target.value })}>
            <option value="">None</option>
            {holders.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Received via">
          <Select value={f.channel_id} onChange={(e) => update({ channel_id: e.target.value })}>
            <option value="">Select…</option>
            {lookups.channels
              .filter((x) => !x.archived || x.id === f.channel_id)
              .map((x) => (
                <option key={x.id} value={x.id}>
                  {x.name}
                </option>
              ))}
          </Select>
        </Field>
        <Field label="Original currency">
          <Select value={f.currency} onChange={(e) => onCurrency(e.target.value as Currency)}>
            {CURRENCIES.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </Select>
        </Field>
      </div>

      <fieldset className="rounded-lg border border-border p-4">
        <legend className="px-1 text-xs font-medium text-muted-fg">Amounts ({f.currency})</legend>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
          <Field label="Gross amount">
            <Input type="number" step="any" min="0" inputMode="decimal" value={f.gross_amount} onChange={(e) => update({ gross_amount: e.target.value })} />
          </Field>
          <Field label="Platform fee">
            <Input type="number" step="any" min="0" inputMode="decimal" value={f.platform_fee} onChange={(e) => update({ platform_fee: e.target.value })} />
          </Field>
          <Field label="Transfer fee">
            <Input type="number" step="any" min="0" inputMode="decimal" value={f.transfer_fee} onChange={(e) => update({ transfer_fee: e.target.value })} />
          </Field>
          <Field label="Other fee">
            <Input type="number" step="any" min="0" inputMode="decimal" value={f.other_fee} onChange={(e) => update({ other_fee: e.target.value })} />
          </Field>
          <Field label="Net amount sent" hint="Auto: gross minus fees">
            <Input
              type="number"
              step="any"
              min="0"
              inputMode="decimal"
              value={f.net_foreign_amount}
              onChange={(e) => {
                touched.current.net = true;
                update({ net_foreign_amount: e.target.value });
              }}
            />
          </Field>
          <Field label="Rate shown (INR per 1)">
            <Input
              type="number"
              step="any"
              min="0"
              inputMode="decimal"
              value={f.conversion_rate}
              disabled={!isForeign}
              onChange={(e) => update({ conversion_rate: e.target.value })}
            />
          </Field>
          <Field label="INR received" hint="Auto: net × rate until you edit" className="col-span-2 sm:col-span-3">
            <Input
              type="number"
              step="any"
              min="0"
              inputMode="decimal"
              value={f.inr_received}
              onChange={(e) => {
                touched.current.inr = true;
                update({ inr_received: e.target.value });
              }}
            />
          </Field>
        </div>
        {isForeign && num(f.net_foreign_amount) > 0 && (
          <dl className="mt-4 grid grid-cols-2 gap-2 rounded-md bg-muted p-3 text-xs sm:grid-cols-4">
            <div>
              <dt className="text-muted-fg">Expected INR</dt>
              <dd className="font-medium">{fmtINR(m.expectedInr)}</dd>
            </div>
            <div>
              <dt className="text-muted-fg">FX / hidden loss</dt>
              <dd className="font-medium">{fmtINR(m.fxLoss)}</dd>
            </div>
            <div>
              <dt className="text-muted-fg">Effective rate</dt>
              <dd className="font-medium">{m.effectiveRate ? round(m.effectiveRate, 4) : "-"}</dd>
            </div>
            <div>
              <dt className="text-muted-fg">Net sent</dt>
              <dd className="font-medium">{fmtForeign(num(f.net_foreign_amount), f.currency)}</dd>
            </div>
          </dl>
        )}
      </fieldset>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="Status">
          <Select value={f.status} onChange={(e) => update({ status: e.target.value as F["status"] })}>
            <option value="received">Received</option>
            <option value="pending">Pending</option>
          </Select>
        </Field>
        {f.status === "received" ? (
          <Field label="Date received">
            <Input type="date" value={f.date_received} onChange={(e) => update({ date_received: e.target.value })} required />
          </Field>
        ) : (
          <Field label="Expected date">
            <Input type="date" value={f.expected_date} onChange={(e) => update({ expected_date: e.target.value })} />
          </Field>
        )}
        <Field label="Work period from">
          <Input type="date" value={f.period_start} onChange={(e) => update({ period_start: e.target.value })} />
        </Field>
        <Field label="Work period to">
          <Input type="date" value={f.period_end} onChange={(e) => update({ period_end: e.target.value })} />
        </Field>
      </div>

      <div className="flex flex-col gap-2">
        <span className="text-xs font-medium text-muted-fg">Tags</span>
        <div className="flex flex-wrap gap-2">
          {lookups.tags.map((t) => {
            const on = f.tag_ids.includes(t.id);
            return (
              <button
                key={t.id}
                type="button"
                onClick={() =>
                  update({ tag_ids: on ? f.tag_ids.filter((x) => x !== t.id) : [...f.tag_ids, t.id] })
                }
                className={cn(
                  "rounded-full border px-3 py-1 text-xs transition-colors",
                  on ? "border-primary bg-primary text-primary-fg" : "border-border hover:bg-muted",
                )}
              >
                {t.name}
              </button>
            );
          })}
          <div className="flex gap-1">
            <Input
              value={newTag}
              onChange={(e) => setNewTag(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  addTag();
                }
              }}
              placeholder="New tag"
              className="h-8 w-28 text-xs"
            />
            <Button type="button" variant="outline" size="sm" onClick={addTag} disabled={pending}>
              Add
            </Button>
          </div>
        </div>
      </div>

      <Field label="Notes">
        <Textarea value={f.notes} onChange={(e) => update({ notes: e.target.value })} />
      </Field>

      {error && <p className="text-sm text-red-600">{error}</p>}

      <div className="sticky bottom-0 -mx-5 -mb-5 flex flex-wrap justify-end gap-2 border-t border-border bg-bg px-5 py-3">
        <Button type="button" variant="ghost" onClick={onClose}>
          Cancel
        </Button>
        {!initial && (
          <Button type="button" variant="outline" disabled={pending} onClick={() => submit(true)}>
            Save &amp; add another
          </Button>
        )}
        <Button type="submit" disabled={pending}>
          {pending ? "Saving…" : "Save"}
        </Button>
      </div>
    </form>
  );
}
