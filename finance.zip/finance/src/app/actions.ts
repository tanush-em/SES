"use server";

import { createClient } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";
import { z } from "zod";

type Result = { ok: true; id?: string } | { ok: false; error: string };

const fail = (error: string): Result => ({ ok: false, error });
const done = (id?: string): Result => {
  revalidatePath("/", "layout");
  return { ok: true, id };
};

const money = z.coerce.number().min(0, "Cannot be negative").default(0);
const optId = z
  .string()
  .nullish()
  .transform((v) => (v ? v : null));
const optDate = z
  .string()
  .nullish()
  .transform((v) => (v ? v : null));
const optText = z
  .string()
  .nullish()
  .transform((v) => (v?.trim() ? v.trim() : null));
const currency = z.enum(["USD", "USDT", "INR"]);

const incomeSchema = z
  .object({
    id: z.string().optional(),
    title: z.string().trim().min(1, "Title is required"),
    source_id: z.string().min(1, "Source is required"),
    account_holder_id: optId,
    channel_id: optId,
    currency,
    gross_amount: money,
    platform_fee: money,
    transfer_fee: money,
    other_fee: money,
    net_foreign_amount: money,
    conversion_rate: z.coerce.number().positive("Rate must be above 0").default(1),
    inr_received: money,
    status: z.enum(["pending", "received"]),
    date_received: optDate,
    expected_date: optDate,
    period_start: optDate,
    period_end: optDate,
    notes: optText,
    tag_ids: z.array(z.string()).default([]),
  })
  .refine((v) => v.status !== "received" || !!v.date_received, {
    message: "Date received is required for received income",
    path: ["date_received"],
  });

export type IncomeInput = z.input<typeof incomeSchema>;

export async function saveIncome(input: IncomeInput): Promise<Result> {
  const p = incomeSchema.safeParse(input);
  if (!p.success) return fail(p.error.issues[0].message);
  const { id, tag_ids, ...row } = p.data;

  const supabase = await createClient();
  let incomeId = id;
  if (id) {
    const { error } = await supabase.from("incomes").update(row).eq("id", id);
    if (error) return fail(error.message);
  } else {
    const { data, error } = await supabase.from("incomes").insert(row).select("id").single();
    if (error) return fail(error.message);
    incomeId = data.id;
  }

  const { error: delErr } = await supabase.from("income_tags").delete().eq("income_id", incomeId!);
  if (delErr) return fail(delErr.message);
  if (tag_ids.length) {
    const { error } = await supabase
      .from("income_tags")
      .insert(tag_ids.map((tag_id) => ({ income_id: incomeId, tag_id })));
    if (error) return fail(error.message);
  }
  return done(incomeId);
}

export async function deleteIncome(id: string): Promise<Result> {
  const supabase = await createClient();
  const { error } = await supabase.from("incomes").delete().eq("id", id);
  return error ? fail(error.message) : done();
}

export async function markIncomeReceived(id: string, dateISO: string): Promise<Result> {
  const supabase = await createClient();
  const { error } = await supabase
    .from("incomes")
    .update({ status: "received", date_received: dateISO })
    .eq("id", id);
  return error ? fail(error.message) : done();
}

const expenseSchema = z.object({
  id: z.string().optional(),
  name: z.string().trim().min(1, "Name is required"),
  type_id: z.string().min(1, "Type is required"),
  payee_id: optId,
  amount_inr: money,
  payee_currency: currency,
  payee_amount: money,
  conversion_rate: z.coerce.number().positive("Rate must be above 0").default(1),
  channel_id: optId,
  transfer_fee_inr: money,
  status: z.enum(["pending", "paid"]),
  date: z.string().min(1, "Date is required"),
  linked_income_id: optId,
  notes: optText,
});

export type ExpenseInput = z.input<typeof expenseSchema>;

export async function saveExpense(input: ExpenseInput): Promise<Result> {
  const p = expenseSchema.safeParse(input);
  if (!p.success) return fail(p.error.issues[0].message);
  const { id, ...row } = p.data;

  const supabase = await createClient();
  if (id) {
    const { error } = await supabase.from("expenses").update(row).eq("id", id);
    if (error) return fail(error.message);
    return done(id);
  }
  const { data, error } = await supabase.from("expenses").insert(row).select("id").single();
  return error ? fail(error.message) : done(data.id);
}

export async function deleteExpense(id: string): Promise<Result> {
  const supabase = await createClient();
  const { error } = await supabase.from("expenses").delete().eq("id", id);
  return error ? fail(error.message) : done();
}

export async function markExpensePaid(id: string, dateISO: string): Promise<Result> {
  const supabase = await createClient();
  const { error } = await supabase
    .from("expenses")
    .update({ status: "paid", date: dateISO })
    .eq("id", id);
  return error ? fail(error.message) : done();
}

// ---------- lookups ----------

const nameSchema = z.string().trim().min(1, "Name is required");

function friendly(message: string) {
  return /duplicate key/i.test(message) ? "That name already exists." : message;
}

export async function saveSource(input: {
  id?: string;
  name: string;
  type: "platform" | "company" | "direct_client";
  notes?: string | null;
}): Promise<Result> {
  const name = nameSchema.safeParse(input.name);
  if (!name.success) return fail(name.error.issues[0].message);
  const row = { name: name.data, type: input.type, notes: input.notes?.trim() || null };
  const supabase = await createClient();
  const { data, error } = input.id
    ? await supabase.from("sources").update(row).eq("id", input.id).select("id").single()
    : await supabase.from("sources").insert(row).select("id").single();
  return error ? fail(friendly(error.message)) : done(data.id);
}

export async function savePerson(input: {
  id?: string;
  name: string;
  is_account_holder: boolean;
  is_payee: boolean;
  contact?: string | null;
  notes?: string | null;
}): Promise<Result> {
  const name = nameSchema.safeParse(input.name);
  if (!name.success) return fail(name.error.issues[0].message);
  const row = {
    name: name.data,
    is_account_holder: input.is_account_holder,
    is_payee: input.is_payee,
    contact: input.contact?.trim() || null,
    notes: input.notes?.trim() || null,
  };
  const supabase = await createClient();
  const { data, error } = input.id
    ? await supabase.from("people").update(row).eq("id", input.id).select("id").single()
    : await supabase.from("people").insert(row).select("id").single();
  return error ? fail(friendly(error.message)) : done(data.id);
}

export async function saveChannel(input: { id?: string; name: string }): Promise<Result> {
  const name = nameSchema.safeParse(input.name);
  if (!name.success) return fail(name.error.issues[0].message);
  const supabase = await createClient();
  const { data, error } = input.id
    ? await supabase.from("payment_channels").update({ name: name.data }).eq("id", input.id).select("id").single()
    : await supabase.from("payment_channels").insert({ name: name.data }).select("id").single();
  return error ? fail(friendly(error.message)) : done(data.id);
}

export async function saveExpenseType(input: {
  id?: string;
  name: string;
  kind: "account_holder_payout" | "other";
}): Promise<Result> {
  const name = nameSchema.safeParse(input.name);
  if (!name.success) return fail(name.error.issues[0].message);
  const row = { name: name.data, kind: input.kind };
  const supabase = await createClient();
  const { data, error } = input.id
    ? await supabase.from("expense_types").update(row).eq("id", input.id).select("id").single()
    : await supabase.from("expense_types").insert(row).select("id").single();
  return error ? fail(friendly(error.message)) : done(data.id);
}

export async function saveTag(input: { name: string }): Promise<Result> {
  const name = nameSchema.safeParse(input.name);
  if (!name.success) return fail(name.error.issues[0].message);
  const supabase = await createClient();
  const { data, error } = await supabase.from("tags").insert({ name: name.data }).select("id").single();
  return error ? fail(friendly(error.message)) : done(data.id);
}

export async function deleteTag(id: string): Promise<Result> {
  const supabase = await createClient();
  const { error } = await supabase.from("tags").delete().eq("id", id);
  return error ? fail(error.message) : done();
}

const ARCHIVABLE = ["sources", "people", "payment_channels", "expense_types"] as const;

export async function setArchived(
  table: (typeof ARCHIVABLE)[number],
  id: string,
  archived: boolean,
): Promise<Result> {
  if (!ARCHIVABLE.includes(table)) return fail("Invalid table");
  const supabase = await createClient();
  const { error } = await supabase.from(table).update({ archived }).eq("id", id);
  return error ? fail(error.message) : done();
}
