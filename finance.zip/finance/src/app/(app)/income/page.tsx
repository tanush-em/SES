import { IncomeTable } from "@/components/income-table";
import { getAllIncomes, getLookups } from "@/lib/data";

export default async function IncomePage() {
  const [incomes, lookups] = await Promise.all([getAllIncomes(), getLookups()]);
  return <IncomeTable incomes={incomes} lookups={lookups} />;
}
