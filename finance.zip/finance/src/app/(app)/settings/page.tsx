import { SettingsManager } from "@/components/settings-manager";
import { getLookups } from "@/lib/data";

export default async function SettingsPage() {
  return <SettingsManager lookups={await getLookups()} />;
}
