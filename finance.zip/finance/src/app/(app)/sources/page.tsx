import { SourcesManager } from "@/components/sources-manager";
import { getAllIncomes, getLookups } from "@/lib/data";
import { num } from "@/lib/format";

export default async function SourcesPage() {
  const [incomes, lookups] = await Promise.all([getAllIncomes(), getLookups()]);

  const rows = lookups.sources.map((s) => {
    const mine = incomes.filter((i) => i.source_id === s.id && i.status === "received");
    return { ...s, count: mine.length, total: mine.reduce((a, i) => a + num(i.inr_received), 0) };
  });

  return <SourcesManager sources={rows} />;
}
