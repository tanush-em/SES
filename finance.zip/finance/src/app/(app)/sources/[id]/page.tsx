import { IncomeTable } from "@/components/income-table";
import { Stat } from "@/components/ui";
import { SOURCE_TYPE_LABEL } from "@/lib/types";
import { getAllIncomes, getLookups } from "@/lib/data";
import { fmtINR, incomeMetrics, num } from "@/lib/format";
import { ArrowLeft } from "lucide-react";
import Link from "next/link";
import { notFound } from "next/navigation";

export default async function SourcePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [allIncomes, lookups] = await Promise.all([getAllIncomes(), getLookups()]);
  const source = lookups.sources.find((s) => s.id === id);
  if (!source) notFound();

  const incomes = allIncomes.filter((i) => i.source_id === id);
  const received = incomes.filter((i) => i.status === "received");
  const total = received.reduce((a, i) => a + num(i.inr_received), 0);
  const cost = received.reduce((a, i) => a + incomeMetrics(i).totalCost, 0);
  const pending = incomes.filter((i) => i.status === "pending");
  const pendingInr = pending.reduce((a, i) => a + (incomeMetrics(i).expectedInr || num(i.inr_received)), 0);

  return (
    <div className="flex flex-col gap-10">
      <div>
        <Link href="/sources" className="mb-2 inline-flex items-center gap-1 text-sm text-muted-fg hover:text-fg">
          <ArrowLeft className="h-4 w-4" /> Sources
        </Link>
        <h1 className="text-2xl font-semibold tracking-tight">{source.name}</h1>
        <p className="mt-1 text-sm text-muted-fg">{SOURCE_TYPE_LABEL[source.type]}</p>
        {source.notes && <p className="mt-1 text-sm text-muted-fg">{source.notes}</p>}
        <div className="mt-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
          <Stat label="Received (all time)" value={fmtINR(total, true)} sub={`${received.length} payouts`} />
          <Stat label="Pending" value={fmtINR(pendingInr, true)} sub={`${pending.length} entries`} />
          <Stat label="Fees + FX loss" value={fmtINR(cost, true)} />
          <Stat label="Average payout" value={received.length ? fmtINR(total / received.length, true) : "-"} />
        </div>
      </div>
      <IncomeTable incomes={incomes} lookups={lookups} preset={{ source: id }} title="Payouts" />
    </div>
  );
}
