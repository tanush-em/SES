import { SharePie, TrendChart } from "@/components/charts";
import { RangePicker } from "@/components/range-picker";
import { Badge, Card, EmptyState, PageHeader, Stat } from "@/components/ui";
import { computeDashboard } from "@/lib/dashboard";
import { getAllExpenses, getAllIncomes, getLookups, incomeDate, resolveRange, type SearchParams } from "@/lib/data";
import { fmtDate, fmtINR, round } from "@/lib/format";
import Link from "next/link";

export default async function DashboardPage({ searchParams }: { searchParams: Promise<SearchParams> }) {
  const range = resolveRange(await searchParams);
  const [incomes, expenses, lookups] = await Promise.all([getAllIncomes(), getAllExpenses(), getLookups()]);
  const d = computeDashboard(incomes, expenses, lookups.people, range);

  const empty = incomes.length === 0 && expenses.length === 0;

  return (
    <>
      <PageHeader
        title="Dashboard"
        description={range.label}
        actions={
          <RangePicker mode={range.mode} month={range.month} fy={range.fy} from={range.from ?? ""} to={range.to ?? ""} />
        }
      />

      {empty && (
        <div className="mb-6">
          <EmptyState>
            Nothing logged yet. Add your <Link className="underline" href="/sources">sources</Link> and{" "}
            <Link className="underline" href="/people">people</Link>, then record your first{" "}
            <Link className="underline" href="/income">income</Link>.
          </EmptyState>
        </div>
      )}

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Income" value={fmtINR(d.income, true)} sub={`${d.rIncomeCount} payouts`} />
        <Stat label="Expenses" value={fmtINR(d.expense, true)} sub={d.pendingExpense ? `${fmtINR(d.pendingExpense, true)} still to pay` : undefined} />
        <Stat label="Net profit" value={fmtINR(d.net, true)} tone={d.net >= 0 ? "good" : "bad"} />
        <Stat label="Pending income" value={fmtINR(d.pendingInr, true)} sub={`${d.pendingCount} not received yet`} />
        <Stat label="Fees + FX loss" value={fmtINR(d.platformFees + d.fxLoss, true)} sub={`Platform ${fmtINR(d.platformFees, true)} · FX ${fmtINR(d.fxLoss, true)}`} />
        {d.rates.map((r) => (
          <Stat
            key={r.currency}
            label={`Avg ${r.currency} rate`}
            value={r.count ? `₹${round(r.effective, 2)}` : "-"}
            sub={r.count ? `Effective, ${r.count} payouts` : "No payouts"}
          />
        ))}
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card className="lg:col-span-2">
          <h2 className="mb-3 text-sm font-semibold">Last 12 months</h2>
          <TrendChart data={d.trend} />
        </Card>
        <Card>
          <h2 className="mb-3 text-sm font-semibold">Income by source</h2>
          <SharePie data={d.bySource} />
        </Card>
        <Card>
          <h2 className="mb-3 text-sm font-semibold">Income by account holder</h2>
          <SharePie data={d.byHolder} />
        </Card>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card>
          <h2 className="mb-3 text-sm font-semibold">Owed to account holders</h2>
          {d.owed.length === 0 ? (
            <p className="text-sm text-muted-fg">No account holder activity yet.</p>
          ) : (
            <table className="w-full text-sm">
              <thead className="text-left text-xs text-muted-fg">
                <tr>
                  <th className="py-1 font-medium">Person</th>
                  <th className="py-1 text-right font-medium">Earned</th>
                  <th className="py-1 text-right font-medium">Paid</th>
                  <th className="py-1 text-right font-medium">Balance</th>
                </tr>
              </thead>
              <tbody>
                {d.owed.map((r) => (
                  <tr key={r.person.id} className="border-t border-border">
                    <td className="py-2">
                      <Link href={`/people/${r.person.id}`} className="font-medium hover:underline">
                        {r.person.name}
                      </Link>
                    </td>
                    <td className="py-2 text-right tabular-nums">{fmtINR(r.earned, true)}</td>
                    <td className="py-2 text-right tabular-nums">{fmtINR(r.paidOut, true)}</td>
                    <td className="py-2 text-right font-medium tabular-nums">{fmtINR(r.balance, true)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          <p className="mt-2 text-xs text-muted-fg">All time. Balance = earned on their account minus account-holder payouts.</p>
        </Card>

        <Card>
          <h2 className="mb-3 text-sm font-semibold">Next pending payments</h2>
          {d.upcoming.length === 0 ? (
            <p className="text-sm text-muted-fg">Nothing pending.</p>
          ) : (
            <ul className="divide-y divide-border">
              {d.upcoming.map((i) => (
                <li key={i.id} className="flex items-center justify-between gap-3 py-2 text-sm">
                  <div className="min-w-0">
                    <div className="truncate font-medium">{i.title}</div>
                    <div className="text-xs text-muted-fg">
                      {i.sources?.name} · {i.people?.name ?? "-"}
                    </div>
                  </div>
                  <div className="shrink-0 text-right">
                    <div className="tabular-nums">{fmtINR(i.net_foreign_amount * i.conversion_rate || i.inr_received, true)}</div>
                    <Badge tone="warn">{incomeDate(i) ? fmtDate(incomeDate(i)) : "no date"}</Badge>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </>
  );
}
