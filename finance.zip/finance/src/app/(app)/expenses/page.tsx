import { ExpenseTable } from "@/components/expense-table";
import { getAllExpenses, getAllIncomes, getLookups } from "@/lib/data";

export default async function ExpensesPage() {
  const [expenses, incomes, lookups] = await Promise.all([
    getAllExpenses(),
    getAllIncomes(),
    getLookups(),
  ]);
  return <ExpenseTable expenses={expenses} incomes={incomes} lookups={lookups} />;
}
