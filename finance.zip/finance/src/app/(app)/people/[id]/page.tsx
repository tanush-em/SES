import { ExpenseTable } from "@/components/expense-table";
import { IncomeTable } from "@/components/income-table";
import { Stat } from "@/components/ui";
import { getAllExpenses, getAllIncomes, getLookups } from "@/lib/data";
import { fmtINR, num } from "@/lib/format";
import { ArrowLeft } from "lucide-react";
import Link from "next/link";
import { notFound } from "next/navigation";

export default async function PersonPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [allIncomes, allExpenses, lookups] = await Promise.all([getAllIncomes(), getAllExpenses(), getLookups()]);
  const person = lookups.people.find((p) => p.id === id);
  if (!person) notFound();

  const incomes = allIncomes.filter((i) => i.account_holder_id === id);
  const expenses = allExpenses.filter((e) => e.payee_id === id);

  const earned = incomes.filter((i) => i.status === "received").reduce((a, i) => a + num(i.inr_received), 0);
  const pendingIn = incomes.filter((i) => i.status === "pending").length;
  const paidOut = expenses
    .filter((e) => e.status === "paid" && e.expense_types?.kind === "account_holder_payout")
    .reduce((a, e) => a + num(e.amount_inr), 0);
  const paidAll = expenses.filter((e) => e.status === "paid").reduce((a, e) => a + num(e.amount_inr), 0);

  return (
    <div className="flex flex-col gap-10">
      <div>
        <Link href="/people" className="mb-2 inline-flex items-center gap-1 text-sm text-muted-fg hover:text-fg">
          <ArrowLeft className="h-4 w-4" /> People
        </Link>
        <h1 className="text-2xl font-semibold tracking-tight">{person.name}</h1>
        {person.contact && <p className="mt-1 text-sm text-muted-fg">{person.contact}</p>}
        {person.notes && <p className="mt-1 text-sm text-muted-fg">{person.notes}</p>}
        <div className="mt-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
          <Stat label="Earned on their accounts" value={fmtINR(earned, true)} sub={pendingIn ? `${pendingIn} pending` : undefined} />
          <Stat label="Account-holder payouts" value={fmtINR(paidOut, true)} />
          <Stat
            label="Balance owed"
            value={person.is_self ? "-" : fmtINR(earned - paidOut, true)}
            tone={!person.is_self && earned - paidOut > 0 ? "bad" : undefined}
            sub="Earned minus payouts"
          />
          <Stat label="All payments to them" value={fmtINR(paidAll, true)} />
        </div>
      </div>
      <section>
        <IncomeTable incomes={incomes} lookups={lookups} preset={{ holder: id }} title="Income on their accounts" />
      </section>
      <section>
        <ExpenseTable
          expenses={expenses}
          incomes={allIncomes}
          lookups={lookups}
          preset={{ payee: id }}
          title="Payments to them"
        />
      </section>
    </div>
  );
}
