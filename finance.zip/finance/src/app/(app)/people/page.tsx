import { PeopleManager } from "@/components/people-manager";
import { getAllExpenses, getAllIncomes, getLookups } from "@/lib/data";
import { num } from "@/lib/format";

export default async function PeoplePage() {
  const [incomes, expenses, lookups] = await Promise.all([getAllIncomes(), getAllExpenses(), getLookups()]);

  const rows = lookups.people.map((p) => ({
    ...p,
    earned: incomes
      .filter((i) => i.status === "received" && i.account_holder_id === p.id)
      .reduce((a, i) => a + num(i.inr_received), 0),
    paidOut: expenses
      .filter((e) => e.status === "paid" && e.payee_id === p.id && e.expense_types?.kind === "account_holder_payout")
      .reduce((a, e) => a + num(e.amount_inr), 0),
  }));

  return <PeopleManager people={rows} />;
}
