import { createClient } from "@/lib/supabase/server";
import { fyStartYear, todayISO } from "@/lib/format";
import type {
  Channel,
  Expense,
  ExpenseType,
  Income,
  Person,
  Source,
  Tag,
} from "@/lib/types";

type Supa = Awaited<ReturnType<typeof createClient>>;

const PAGE = 1000;

/** PostgREST caps responses at 1000 rows, so page through a query until exhausted. */
export async function fetchAll<T>(
  build: (from: number, to: number) => PromiseLike<{ data: T[] | null; error: { message: string } | null }>,
): Promise<T[]> {
  const out: T[] = [];
  for (let from = 0; ; from += PAGE) {
    const { data, error } = await build(from, from + PAGE - 1);
    if (error) throw new Error(error.message);
    if (!data?.length) break;
    out.push(...data);
    if (data.length < PAGE) break;
  }
  return out;
}

export async function getLookups(supabase?: Supa) {
  const s = supabase ?? (await createClient());
  const [sources, people, channels, expenseTypes, tags] = await Promise.all([
    s.from("sources").select("*").order("name"),
    s.from("people").select("*").order("name"),
    s.from("payment_channels").select("*").order("name"),
    s.from("expense_types").select("*").order("name"),
    s.from("tags").select("*").order("name"),
  ]);
  for (const r of [sources, people, channels, expenseTypes, tags]) {
    if (r.error) throw new Error(r.error.message);
  }
  return {
    sources: sources.data as Source[],
    people: people.data as Person[],
    channels: channels.data as Channel[],
    expenseTypes: expenseTypes.data as ExpenseType[],
    tags: tags.data as Tag[],
  };
}
export type Lookups = Awaited<ReturnType<typeof getLookups>>;

export const INCOME_SELECT =
  "*, sources(name), people(name), payment_channels(name), income_tags(tag_id)";
export const EXPENSE_SELECT =
  "*, expense_types(name, kind), people(name), payment_channels(name), incomes(title)";

export async function getAllIncomes(): Promise<Income[]> {
  const s = await createClient();
  return fetchAll<Income>((from, to) =>
    s
      .from("incomes")
      .select(INCOME_SELECT)
      .order("created_at", { ascending: false })
      .range(from, to) as unknown as PromiseLike<{ data: Income[] | null; error: { message: string } | null }>,
  );
}

export async function getAllExpenses(): Promise<Expense[]> {
  const s = await createClient();
  return fetchAll<Expense>((from, to) =>
    s
      .from("expenses")
      .select(EXPENSE_SELECT)
      .order("created_at", { ascending: false })
      .range(from, to) as unknown as PromiseLike<{ data: Expense[] | null; error: { message: string } | null }>,
  );
}

/** Date an income counts toward: when it landed, else when it's expected. */
export const incomeDate = (i: Income) =>
  i.status === "received" ? i.date_received ?? i.expected_date : i.expected_date ?? i.date_received;

export interface Range {
  from: string | null;
  to: string | null;
  label: string;
  mode: "month" | "fy" | "all" | "custom";
  month: string;
  fy: number;
}

export type SearchParams = Record<string, string | string[] | undefined>;
const first = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v);

export function resolveRange(sp: SearchParams): Range {
  const today = todayISO();
  const month = /^\d{4}-\d{2}$/.test(first(sp.month) ?? "") ? first(sp.month)! : today.slice(0, 7);
  const fy = parseInt(first(sp.fy) ?? "", 10) || fyStartYear();
  const mode = (["month", "fy", "all", "custom"].includes(first(sp.range) ?? "")
    ? first(sp.range)
    : "month") as Range["mode"];

  if (mode === "all") return { from: null, to: null, label: "All time", mode, month, fy };
  if (mode === "fy")
    return {
      from: `${fy}-04-01`,
      to: `${fy + 1}-03-31`,
      label: `FY ${fy}-${String(fy + 1).slice(2)}`,
      mode,
      month,
      fy,
    };
  if (mode === "custom") {
    const from = first(sp.from) || null;
    const to = first(sp.to) || null;
    return { from, to, label: `${from ?? "start"} to ${to ?? "today"}`, mode, month, fy };
  }
  const [y, m] = month.split("-").map(Number);
  const last = new Date(y, m, 0).getDate();
  return {
    from: `${month}-01`,
    to: `${month}-${String(last).padStart(2, "0")}`,
    label: new Date(y, m - 1, 1).toLocaleDateString("en-IN", { month: "long", year: "numeric" }),
    mode,
    month,
    fy,
  };
}

export const inRange = (d: string | null | undefined, r: Range) =>
  !!d && (!r.from || d >= r.from) && (!r.to || d <= r.to);
