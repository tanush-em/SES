export type Currency = "USD" | "USDT" | "INR";
export const CURRENCIES: Currency[] = ["USD", "USDT", "INR"];

export type SourceType = "platform" | "company" | "direct_client";
export const SOURCE_TYPE_LABEL: Record<SourceType, string> = {
  platform: "Platform",
  company: "Company",
  direct_client: "Direct client",
};

export type IncomeStatus = "pending" | "received";
export type ExpenseStatus = "pending" | "paid";

export interface Source {
  id: string;
  name: string;
  type: SourceType;
  notes: string | null;
  archived: boolean;
}

export interface Person {
  id: string;
  name: string;
  is_self: boolean;
  is_account_holder: boolean;
  is_payee: boolean;
  contact: string | null;
  notes: string | null;
  archived: boolean;
}

export interface Channel {
  id: string;
  name: string;
  archived: boolean;
}

export interface ExpenseType {
  id: string;
  name: string;
  kind: "account_holder_payout" | "other";
  archived: boolean;
}

export interface Tag {
  id: string;
  name: string;
}

export interface Income {
  id: string;
  title: string;
  source_id: string;
  account_holder_id: string | null;
  channel_id: string | null;
  currency: Currency;
  gross_amount: number;
  platform_fee: number;
  transfer_fee: number;
  other_fee: number;
  net_foreign_amount: number;
  conversion_rate: number;
  inr_received: number;
  status: IncomeStatus;
  date_received: string | null;
  expected_date: string | null;
  period_start: string | null;
  period_end: string | null;
  notes: string | null;
  created_at: string;
  sources?: { name: string } | null;
  people?: { name: string } | null;
  payment_channels?: { name: string } | null;
  income_tags?: { tag_id: string }[];
}

export interface Expense {
  id: string;
  name: string;
  type_id: string;
  payee_id: string | null;
  amount_inr: number;
  payee_currency: Currency;
  payee_amount: number;
  conversion_rate: number;
  channel_id: string | null;
  transfer_fee_inr: number;
  status: ExpenseStatus;
  date: string;
  linked_income_id: string | null;
  notes: string | null;
  created_at: string;
  expense_types?: { name: string; kind: string } | null;
  people?: { name: string } | null;
  payment_channels?: { name: string } | null;
  incomes?: { title: string } | null;
}
