import type { Currency, Income } from "./types";

export const num = (v: unknown): number => {
  const n = typeof v === "string" ? parseFloat(v) : (v as number);
  return Number.isFinite(n) ? n : 0;
};

export const round = (n: number, dp = 2) => {
  const f = 10 ** dp;
  return Math.round((n + Number.EPSILON) * f) / f;
};

const inr = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 2,
});
const inrWhole = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

export const fmtINR = (n: number, whole = false) =>
  (whole ? inrWhole : inr).format(num(n));

export const fmtForeign = (n: number, currency: Currency) => {
  if (currency === "INR") return fmtINR(n);
  const s = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 4,
  }).format(num(n));
  return `${s} ${currency}`;
};

export const fmtDate = (d: string | null | undefined) => {
  if (!d) return "-";
  const [y, m, day] = d.slice(0, 10).split("-").map(Number);
  return new Date(y, m - 1, day).toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

export const todayISO = () => {
  const d = new Date();
  const off = d.getTimezoneOffset() * 60000;
  return new Date(d.getTime() - off).toISOString().slice(0, 10);
};

/** Fees are stored in the foreign currency; the gap between expected and actual INR is the FX/hidden loss. */
export function incomeMetrics(i: Pick<
  Income,
  | "currency"
  | "gross_amount"
  | "platform_fee"
  | "transfer_fee"
  | "other_fee"
  | "net_foreign_amount"
  | "conversion_rate"
  | "inr_received"
>) {
  const rate = num(i.conversion_rate) || 1;
  const expectedInr = num(i.net_foreign_amount) * rate;
  const fxLoss = Math.max(0, expectedInr - num(i.inr_received));
  const platformFeeInr = num(i.platform_fee) * rate;
  const otherFeesInr = (num(i.transfer_fee) + num(i.other_fee)) * rate;
  // transfer/other fees are already inside the net-vs-received gap, so only platform fee is added to avoid double counting
  const totalCost = platformFeeInr + fxLoss;
  const grossInr = num(i.gross_amount) * rate;
  const effectiveRate = num(i.gross_amount)
    ? num(i.inr_received) / num(i.gross_amount)
    : 0;
  return { expectedInr, fxLoss, platformFeeInr, otherFeesInr, totalCost, grossInr, effectiveRate };
}

/** Financial year (Apr-Mar) start year for a date string. */
export function fyStartYear(d = new Date()) {
  return d.getMonth() >= 3 ? d.getFullYear() : d.getFullYear() - 1;
}

export const monthKey = (d: string) => d.slice(0, 7);

export function monthLabel(key: string) {
  const [y, m] = key.split("-").map(Number);
  return new Date(y, m - 1, 1).toLocaleDateString("en-IN", {
    month: "short",
    year: "2-digit",
  });
}

export function lastNMonths(n: number, from = new Date()) {
  const out: string[] = [];
  for (let k = n - 1; k >= 0; k--) {
    const d = new Date(from.getFullYear(), from.getMonth() - k, 1);
    out.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`);
  }
  return out;
}
