import { incomeDate, inRange, type Range } from "@/lib/data";
import { incomeMetrics, lastNMonths, monthKey, num } from "@/lib/format";
import type { Expense, Income, Person } from "@/lib/types";

export function computeDashboard(incomes: Income[], expenses: Expense[], people: Person[], range: Range) {
  const received = incomes.filter((i) => i.status === "received");
  const pending = incomes.filter((i) => i.status === "pending");
  const paid = expenses.filter((e) => e.status === "paid");

  const rIncome = received.filter((i) => inRange(i.date_received, range));
  const rExpense = paid.filter((e) => inRange(e.date, range));

  const income = rIncome.reduce((a, i) => a + num(i.inr_received), 0);
  const expense = rExpense.reduce((a, e) => a + num(e.amount_inr) + num(e.transfer_fee_inr), 0);

  const pendingInr = pending.reduce((a, i) => {
    const m = incomeMetrics(i);
    return a + (m.expectedInr || num(i.inr_received));
  }, 0);
  const pendingExpense = expenses
    .filter((e) => e.status === "pending")
    .reduce((a, e) => a + num(e.amount_inr) + num(e.transfer_fee_inr), 0);

  let platformFees = 0;
  let fxLoss = 0;
  for (const i of rIncome) {
    const m = incomeMetrics(i);
    platformFees += m.platformFeeInr;
    fxLoss += m.fxLoss;
  }

  const rates = (["USD", "USDT"] as const).map((c) => {
    const rows = rIncome.filter((i) => i.currency === c && num(i.gross_amount) > 0);
    const gross = rows.reduce((a, i) => a + num(i.gross_amount), 0);
    const inr = rows.reduce((a, i) => a + num(i.inr_received), 0);
    return { currency: c, count: rows.length, effective: gross ? inr / gross : 0 };
  });

  const group = (key: (i: Income) => string) => {
    const map = new Map<string, number>();
    for (const i of rIncome) map.set(key(i), (map.get(key(i)) ?? 0) + num(i.inr_received));
    return [...map.entries()].map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  };
  const bySource = group((i) => i.sources?.name ?? "Unknown");
  const byHolder = group((i) => i.people?.name ?? "No holder");

  const months = lastNMonths(12);
  const trend = months.map((m) => ({
    month: m,
    income: received.filter((i) => i.date_received && monthKey(i.date_received) === m).reduce((a, i) => a + num(i.inr_received), 0),
    expenses: paid
      .filter((e) => monthKey(e.date) === m)
      .reduce((a, e) => a + num(e.amount_inr) + num(e.transfer_fee_inr), 0),
  }));

  // all-time balance: earned on their account vs paid to them as account-holder payouts
  const owed = people
    .filter((p) => !p.is_self)
    .map((p) => {
      const earned = received.filter((i) => i.account_holder_id === p.id).reduce((a, i) => a + num(i.inr_received), 0);
      const paidOut = paid
        .filter((e) => e.payee_id === p.id && e.expense_types?.kind === "account_holder_payout")
        .reduce((a, e) => a + num(e.amount_inr), 0);
      return { person: p, earned, paidOut, balance: earned - paidOut };
    })
    .filter((r) => r.earned > 0 || r.paidOut > 0)
    .sort((a, b) => b.balance - a.balance);

  const upcoming = [...pending]
    .sort((a, b) => (incomeDate(a) ?? "").localeCompare(incomeDate(b) ?? ""))
    .slice(0, 5);

  return {
    income,
    expense,
    net: income - expense,
    pendingInr,
    pendingCount: pending.length,
    pendingExpense,
    platformFees,
    fxLoss,
    rates,
    bySource,
    byHolder,
    trend,
    owed,
    upcoming,
    rIncomeCount: rIncome.length,
  };
}
