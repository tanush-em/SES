# Gig Finance

Personal income and expense tracker for freelance gigs. Next.js (App Router) + Supabase (Postgres + auth). Single user.

## Setup

1. Create a Supabase project.
2. In the SQL editor, run `supabase/schema.sql`.
3. Authentication -> Users -> add your user (email + password). Then disable "Allow new users to sign up" in the sign-in settings.
4. Copy `.env.example` to `.env.local` and fill in the project URL and anon key (Project Settings -> API).
5. `npm install` then `npm run dev`.

First login seeds "Self", payment channels and expense types.

## Deploy

Import the repo in Vercel and set the same two environment variables.

## Notes

- Row Level Security restricts every table to the signed-in user.
- Income fees are in the original currency. "FX / hidden loss" = (net amount x rate shown) - INR received. "Fees + FX loss" = platform fee in INR + that loss; transfer and other fees are already inside the gap, so they are not added again.
- Owed balance per account holder = INR received on their accounts - expenses to them whose type is marked "Account-holder payout" (Settings).
