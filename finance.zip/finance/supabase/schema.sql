-- Run this whole file once in Supabase: SQL Editor -> New query -> paste -> Run.
-- Single-user app: every row is owned by auth.uid() and protected by RLS.

create extension if not exists "pgcrypto";

-- ---------- enums ----------
do $$ begin
  create type source_type as enum ('platform', 'company', 'direct_client');
exception when duplicate_object then null; end $$;

do $$ begin
  create type currency_code as enum ('USD', 'USDT', 'INR');
exception when duplicate_object then null; end $$;

do $$ begin
  create type income_status as enum ('pending', 'received');
exception when duplicate_object then null; end $$;

do $$ begin
  create type expense_status as enum ('pending', 'paid');
exception when duplicate_object then null; end $$;

-- ---------- lookup tables ----------
create table if not exists sources (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name text not null,
  type source_type not null default 'platform',
  notes text,
  archived boolean not null default false,
  created_at timestamptz not null default now(),
  unique (user_id, name)
);

create table if not exists people (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name text not null,
  is_self boolean not null default false,
  is_account_holder boolean not null default false,
  is_payee boolean not null default false,
  contact text,
  notes text,
  archived boolean not null default false,
  created_at timestamptz not null default now(),
  unique (user_id, name)
);

create table if not exists payment_channels (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name text not null,
  archived boolean not null default false,
  created_at timestamptz not null default now(),
  unique (user_id, name)
);

create table if not exists expense_types (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name text not null,
  -- 'account_holder_payout' feeds the "owed" calculation
  kind text not null default 'other' check (kind in ('account_holder_payout', 'other')),
  archived boolean not null default false,
  created_at timestamptz not null default now(),
  unique (user_id, name)
);

create table if not exists tags (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name text not null,
  created_at timestamptz not null default now(),
  unique (user_id, name)
);

-- ---------- incomes ----------
create table if not exists incomes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  title text not null,
  source_id uuid not null references sources(id) on delete restrict,
  account_holder_id uuid references people(id) on delete restrict,
  channel_id uuid references payment_channels(id) on delete set null,
  currency currency_code not null default 'USD',
  gross_amount numeric(18,4) not null default 0,       -- foreign currency, before any fee
  platform_fee numeric(18,4) not null default 0,       -- foreign currency
  transfer_fee numeric(18,4) not null default 0,       -- foreign currency
  other_fee numeric(18,4) not null default 0,          -- foreign currency
  net_foreign_amount numeric(18,4) not null default 0, -- foreign currency actually sent to you
  conversion_rate numeric(18,6) not null default 1,    -- rate shown by PayPal/Wise/etc.
  inr_received numeric(18,2) not null default 0,       -- final INR in hand
  status income_status not null default 'received',
  date_received date,
  expected_date date,
  period_start date,
  period_end date,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists incomes_user_date_idx on incomes (user_id, date_received desc);
create index if not exists incomes_source_idx on incomes (source_id);
create index if not exists incomes_holder_idx on incomes (account_holder_id);

create table if not exists income_tags (
  income_id uuid not null references incomes(id) on delete cascade,
  tag_id uuid not null references tags(id) on delete cascade,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  primary key (income_id, tag_id)
);

-- ---------- expenses ----------
create table if not exists expenses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name text not null,
  type_id uuid not null references expense_types(id) on delete restrict,
  payee_id uuid references people(id) on delete restrict,
  amount_inr numeric(18,2) not null default 0,         -- what left your pocket in INR
  payee_currency currency_code not null default 'INR',
  payee_amount numeric(18,4) not null default 0,       -- what the payee received
  conversion_rate numeric(18,6) not null default 1,    -- INR per 1 unit of payee currency
  channel_id uuid references payment_channels(id) on delete set null,
  transfer_fee_inr numeric(18,2) not null default 0,
  status expense_status not null default 'paid',
  date date not null default current_date,
  linked_income_id uuid references incomes(id) on delete set null,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists expenses_user_date_idx on expenses (user_id, date desc);
create index if not exists expenses_payee_idx on expenses (payee_id);

-- ---------- updated_at trigger ----------
create or replace function set_updated_at() returns trigger as $$
begin
  new.updated_at = now();
  return new;
end $$ language plpgsql;

drop trigger if exists incomes_updated_at on incomes;
create trigger incomes_updated_at before update on incomes
  for each row execute function set_updated_at();

drop trigger if exists expenses_updated_at on expenses;
create trigger expenses_updated_at before update on expenses
  for each row execute function set_updated_at();

-- ---------- row level security ----------
do $$
declare t text;
begin
  foreach t in array array[
    'sources','people','payment_channels','expense_types','tags',
    'incomes','income_tags','expenses'
  ] loop
    execute format('alter table %I enable row level security', t);
    execute format('drop policy if exists "owner_all" on %I', t);
    execute format(
      'create policy "owner_all" on %I for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid())',
      t
    );
  end loop;
end $$;

-- ---------- seed defaults for the signed-in user ----------
-- Call once after your first login: select seed_defaults();
create or replace function seed_defaults() returns void
language plpgsql security invoker as $$
begin
  insert into people (name, is_self, is_account_holder)
    values ('Self', true, true) on conflict do nothing;

  insert into payment_channels (name)
    select unnest(array['PayPal','Stripe','Bank transfer','UPI','Crypto exchange','Cash'])
    on conflict do nothing;

  insert into expense_types (name, kind) values
    ('Payout to employee', 'other'),
    ('Payout to account holder', 'account_holder_payout'),
    ('Subscription', 'other'),
    ('Personal draw', 'other')
  on conflict do nothing;
end $$;
